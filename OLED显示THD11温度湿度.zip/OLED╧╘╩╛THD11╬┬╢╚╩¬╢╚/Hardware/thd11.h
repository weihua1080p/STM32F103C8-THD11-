#ifndef __THD11_H
#define __THD11_H

void DHT11_OUT(void);
void DHT11_IN(void);
void DHT11_Rst(void);
u8 DHT11_ReceOneByte (void);
void DHT11_Go(void);

void  COM(void);
void RH(void);

#endif
