#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"

int j,k;

void UI_one(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10 | GPIO_Pin_11;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_10) == 0)
		{
			Delay_ms(20);
			while (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_10) == 0);
			Delay_ms(20);
			j++;
			if (j<1||j>3)	j=1;
		}
	if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_11) == 0)
		{
			Delay_ms(20);
			while (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_11) == 0);
			Delay_ms(20);
			j--;
		}
	switch(j)
		{
			case(1):
				OLED_ShowString(1, 3, "HelloWorld!");
				OLED_ShowString(2, 3, "          !");
				OLED_ShowString(3, 3, "          !");
			break ;
			case(2):
				OLED_ShowString(1, 3, "          !");
				OLED_ShowString(2, 3, "HelloWorld!");
				OLED_ShowString(3, 3, "          !");
			break ;
			case(3):
				OLED_ShowString(1, 3, "          !");
				OLED_ShowString(2, 3, "          !");
				OLED_ShowString(3, 3, "HelloWorld!");
			break ;
			default:
				OLED_Clear();
				j=1;
			break;
		}
	OLED_ShowNum(1, 1, j, 1);
	Delay_ms(100);
	j=(j+1)/3;
	OLED_ShowChar(2, 1, 'A');
		
}
