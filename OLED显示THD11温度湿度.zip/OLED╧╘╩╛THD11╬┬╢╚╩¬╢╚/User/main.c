#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Thd11.h"
#include "Timer.h"

u8 receData[5];

u8 i,x;
u8 RH_data_H, RH_data_L , T_data_H , T_data_L , checkdata;

int main(void)
{
	OLED_Init();
	Timer_Init();
	
//	OLED_ShowChar(1, 16, 'A');
//	OLED_ShowString(1, 3, "HelloWorld!");
//	OLED_ShowNum(2, 1, 12345, 5);
//	OLED_ShowSignedNum(2, 7, -66, 2);
//	OLED_ShowHexNum(3, 1, 0xAA55, 4);
//	OLED_ShowBinNum(4, 1, 0xAA55, 16);
	
	OLED_ShowChar(1, 3, '%');
	OLED_ShowChar(1, 9, 'C');
	OLED_ShowChar(1, 7, '.');
	OLED_ShowString(1, 14, "Fps");
	while (1)
	{
//		DHT11_Rst();
//		receData[0] = DHT11_ReceOneByte();   // ʪ������
//		OLED_ShowNum(1, 1, receData[0], 2);
//		receData[1] = DHT11_ReceOneByte();   // ʪ��С��
//		OLED_ShowNum(2, 1, receData[1], 2);
//		receData[2] = DHT11_ReceOneByte();   // �¶�����
//		OLED_ShowNum(3, 1, receData[2], 2);
//		receData[3] = DHT11_ReceOneByte();   // �¶�С��
//		OLED_ShowNum(4, 1, receData[3], 2);
//		receData[4]	= DHT11_ReceOneByte();   // У����
//		DHT11_Go();		
		

		RH();
		OLED_ShowNum(1, 1, RH_data_H, 2);
//		OLED_ShowNum(1, 4, RH_data_L, 1);
		OLED_ShowNum(1, 5, T_data_H, 2);
		OLED_ShowNum(1, 8, T_data_L, 1);
		
		OLED_ShowNum(1, 12, x, 2);
		i++;		
//		Delay_ms(2000);
	}
}
void TIM2_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM2,TIM_IT_Update)==SET)	//�����ȡ��TIM2�����жϵ���1
	{
		x=i;
		i=0;
		TIM_ClearITPendingBit(TIM2,TIM_IT_Update);	//���TIM2�����ж�
	}		
}